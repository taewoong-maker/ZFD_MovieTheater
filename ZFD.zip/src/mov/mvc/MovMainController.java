package mov.mvc;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import mov.sql.MovDAO;
import mov.sql.MovDTO;
import mov.sql.MovRevDAO;

@WebServlet("/movMain.do")
public class MovMainController extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doUser(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doUser(request, response);
	}
	
	protected void doUser(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html; charset=UTF-8");
		
		MovDAO md = new MovDAO();
		MovRevDAO mvd = new MovRevDAO();
		ArrayList<MovDTO> al=md.posterSel();
		ArrayList<MovDTO> nt = md.dbNoticeSelect10();
		ArrayList<MovDTO> rv = mvd.dbRevSelect10();
		
		request.setAttribute("nt", nt);
		request.setAttribute("rv", rv);
		request.setAttribute("al", al);
		
		RequestDispatcher dis = request.getRequestDispatcher("main.jsp");
		
		dis.forward(request, response);
	}
}
