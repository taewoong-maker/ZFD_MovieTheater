package mov.mvc;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import mov.sql.MovDAO;
import mov.sql.MovDTO;
import mov.sql.MovLoginDAO;
import mov.sql.MovLoginDTO;

@WebServlet("/MovCkDetaillist.do")
public class MovReserveCkDetailListController extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doUser(request, response);
	}//GetEnd

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doUser(request, response);
	}//postEnd
	protected void doUser(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html; charset=UTF-8");
		request.setCharacterEncoding("UTF-8");
		HttpSession session = request.getSession();
		String LoginId=(String)session.getAttribute("LoginId");
		System.out.println("2222�Ѿ�°��Դϴ� : "+LoginId);
		PrintWriter out  =response.getWriter();
		String name = request.getParameter("name");
		String schedule = request.getParameter("schedule");
		String group = request.getParameter("group");
		MovDAO dao = new MovDAO();
		
		ArrayList<MovDTO> seat=dao.dbReserveDetail(LoginId, group, schedule);
		    String userseatJson = "[";     
		    for(int i=0;i<seat.size();i++) {
		    	MovDTO dto = seat.get(i);
		    	userseatJson =   userseatJson+               
		    		       "{\"seatnum\":\""+dto.getSeatNum()+"\"}";
		    	if(seat.size()>0&&i<seat.size()-1) {
		    		userseatJson=userseatJson+",";
		    	}
		    }
		    userseatJson =  userseatJson+ "]";
		    System.out.println("size : " + seat.size());
		       System.out.println("userseatJson : " + userseatJson);
			 try {
		          response.getWriter().print(userseatJson);
		      } catch (IOException e) {
		          e.printStackTrace();
		      }   
		
		
	}//UserEnd
	
}//servlet end
