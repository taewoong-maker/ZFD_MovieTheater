package mov.mvc;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import mov.sql.MovLoginDAO;
import mov.sql.MovLoginDTO;

@WebServlet("/MovLoginController.do")
public class MovLoginController extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doUser(request, response);
	}//GetEnd

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doUser(request, response);
	}//postEnd
	protected void doUser(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html; charset=UTF-8");
		request.setCharacterEncoding("UTF-8");
		PrintWriter out  =response.getWriter();
		
		String LoginId = request.getParameter("username");
		String LoginPWD = request.getParameter("password");

		MovLoginDAO MLDAO = new MovLoginDAO();
	
		int Mcnt1 = MLDAO.dbLogin(LoginId, LoginPWD);
		int Mcnt2 = MLDAO.dbAdminLogin(LoginId, LoginPWD);
		
		if (Mcnt1 > 0 || Mcnt2>0) {
			HttpSession session = request.getSession();
			if(Mcnt1>0) {
				session.setAttribute("LoginId", LoginId);
			}else {
				session.setAttribute("LoginAdmin", LoginId);
			}			
			RequestDispatcher dis = request.getRequestDispatcher("movMain.do");
			dis.forward(request, response);
		} else {
			response.sendRedirect("LoginCheck.jsp");
		}
	}//UserEnd
	
}//servlet end
