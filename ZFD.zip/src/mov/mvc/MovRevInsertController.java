package mov.mvc;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import mov.sql.MovRevDAO;

@WebServlet("/movRevInsert.do")
public class MovRevInsertController extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doUser(request,response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doUser(request,response);
	}
	
	public void doUser(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html; charset=UTF-8");		
		
		String movCode = request.getParameter("idx");//idx=movcode
		String title =request.getParameter("title");
		String content =request.getParameter("content");
		
		HttpSession session = request.getSession();		
		int userCode = (int)session.getAttribute("userCode");
		
		MovRevDAO mvd=new MovRevDAO();
		
		mvd.dbRevInsert(movCode,title,userCode,content);

		response.sendRedirect("movRevList.do?idx="+movCode);
	}

}
