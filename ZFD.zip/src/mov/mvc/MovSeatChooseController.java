package mov.mvc;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import mov.sql.MovDAO;
import mov.sql.MovDTO;
import mov.sql.MovLoginDAO;

@WebServlet("/movSeatChoose.do")
public class MovSeatChooseController extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doUser(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doUser(request, response);
	}
	
	protected void doUser(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html; charset=UTF-8");
		
		//1 ��ü ����
		MovDAO md = new MovDAO();
		PrintWriter out = response.getWriter();
		HttpSession session = request.getSession();
		MovLoginDAO mld = new MovLoginDAO();
		
		String schedule = request.getParameter("schedule");
		String detail = request.getParameter("detail");
		String id = (String) session.getAttribute("LoginId"); //id ���ǰ� ������
					
		if(mld.dbIdCheck(id)!=1) {
			out.println("<script>");	
      out.println("alert('�α����� �ʿ��մϴ�.'); location.href='Mov_Login.jsp';");
      out.println("</script>");
      return;
		}
		
		ArrayList<MovDTO> list = md.selBookedSeat(schedule);
		String seats="";
		int i=0;
		for(i=0;i<list.size();i++) {
			seats+=list.get(i).getSeatNum()+",";
		}		
		
//		System.out.println(seats);
		System.out.println("schedule : "+schedule);
		request.setAttribute("dto",md.movScheduleSel(schedule, detail));
		request.setAttribute("seats",seats);
		request.setAttribute("schedule",schedule);
		request.setAttribute("detail",detail);
		
		RequestDispatcher dis = request.getRequestDispatcher("Mov_SeatChoose.jsp");
		dis.forward(request, response);
	}
}
