$(function(){
   
  	$('.stars .fa').click(function(){
		$(this).addClass('active')
		$(this).prevAll().addClass('active')
		$(this).nextAll().removeClass('active')
	
		var num = $(this).index()
		var starRate = num + 1
		var movCode=$('.stars').attr("data");
		//$('.print').text(starRate)
		location.href="movDetail.do?idx="+movCode+"&point="+starRate;		
	})
		
   $('.btn li:first-child').addClass('active');
   $('.btn li').click(function(){
//	  alert($(this).attr("data"));
      var movCode=$(this).attr("data2");      
      var dateArr=$(this).attr("data1").split('/');      
      $.ajax({    
			url : "movScheduleAjax.do",
			type : "post",
			dataType : "json",
			data : {"idx":movCode,
				"date":dateArr[1]},
			success : function(data) {
				$('.outerTime').empty();
				var html = '';
//				alert(data);
				for(var i in data){
					html += '<div class="innerTime" data-detail="'+data[i].MovDetailCode
									+'" data-schedule="'+data[i].scheduleCode+'">';
					html += '<div>'+data[i].theaterCode+'관</div>';
					html += '<div>'+data[i].movType+'</div>';
					html += '<div>'+data[i].scheduleMonth+"/"+ data[i].scheduleDate+'</div>';
					html += '<div>'+data[i].scheduleTime+'</div>';
					html += '<div>잔여석 : '+ (40-data[i].seat)+'/40</div>';
					html += '</div> ';
					$('.outerTime').html(html);
				}
//				alert(html);
			},
			error:function(){
				alert("실패");
			}
    	});//ajax end
      
        $(this).addClass('active')
	  	$(this).siblings().removeClass('active')
	    
	  	var result = $(this).attr('data-alt')
	  	$('.tabs div').removeClass('active')
	  	$('#' + result).addClass('active')
      });//innerDate click end
   
   $(document).on("click", ".innerTime",function(){
   		var detail = $(this).attr("data-detail");
   		var scheduleCode = $(this).attr("data-schedule");
//   		alert("detail : " + detail+
//   				"scheduleCode : " + scheduleCode);
   		console.log(detail + " " + scheduleCode);
   		location.href="movSeatChoose.do?schedule="+scheduleCode+"&detail="+detail;
   	})
   	
	$('.stars .fa').on({
		  "mouseenter": function(){
		  $(this).addClass('active');
		  $(this).prevAll().addClass('active');
		  },
		  "mouseleave":function(){
		  $(this).removeClass('active');
		  $(this).prevAll().removeClass('active');
		  }
	});
});