$(function(){
    var num;   
    var sum=0;
    var countSeats=0;
    var seatArr = new Array();
    $('.plus').click(function(){
        if(sum<5){
            $('.movSeats tbody tr td span').css({opacity: 1});
        }
        var plus = $(this).prev()
        num = plus.attr("value");        
        sum=counting();
        if(sum<5){
            nextNum = Number(num)+1;
            plus.attr("value",nextNum)
            plus.text(nextNum);
        }    
        sum=counting();
        totalPeople(sum);        
    })

    $('.minus').click(function(){
        if(sum<=countSeats){
            alert("선택한 좌석이 예매를 원하는 좌석보다 많습니다.");
            return;
        }            
        var minus=$(this).next();
        num = minus.attr("value");
        sum=counting();
        if(num>0){
            nextNum = Number(num)-1;
            minus.attr("value",nextNum)
            minus.text(nextNum);
        }        
        sum=counting();
        totalPeople(sum);
        if(sum==0){
            $('.movSeats tbody tr td span').css({opacity: 0.4});
            $('.movSeats').attr('disabled', true);
        }	
    })

    function counting(){
        var sum=0;
        var tempArray = new Array();
        $(".numArea").each(function(){
            tempArray.push($(this).attr("value"));
        });       
        for(var i=0;i<tempArray.length;i++){
            sum=sum+Number(tempArray[i]);
        }
        return sum;
    }

    function totalPeople(num){
        $('.peopleSum').val(num);
    }

////////////////////////////////////////////////////////////

    var TableRows = $('.movSeats tr');
    var emptyCell = '<td class="emptyCell"></td>';

    for(var i=1; i<=TableRows.length;i++){
        var rowID = 1;
        var colID = $('.movSeats tr:nth-child('+i+') td:nth-child('+1+')').text();
        var appendString;
            //tr태그의 i번째에서 td태그의 1번째 글자 A~H
        if(i%2==0){
        // <TR>행생성(.movSeats tr td의 개수)
            for(var j=0; j<=10;j++){
                var id = colID+rowID;                
                if((j<5&&j%2==1)||(j>5&&j%2==0)){
                    appendAvail(id, i)
                }else if (j==5) {
                    // appendString = '<td><span class="tdBox emptyBox" id=' + id + '></span></td>';
                    $('.movSeats tbody tr:nth-child('+i+')').append(emptyCell);
                    rowID--;//rowID;
                }else{
                    appendBlack(i);
                }
                rowID++;
            }            
        }else{
            for(var j=0; j<=10;j++){
                var id = colID+rowID;    
                if((j<5&&j%2==0)||(j>5&&j%2==1)){
                    appendAvail(id, i)
                }else if (j==5) {
                    // appendString = '<td><span class="tdBox emptyBox" id=' + id + '></span></td>';
                    $('.movSeats tbody tr:nth-child('+i+')').append(emptyCell);
                    rowID--;//rowID;
                }else{
                    appendBlack(i);
                }
                rowID++;
            }
        }
    }
    function appendAvail(id, i){
        appendString='<td><span class="tdBox avail" id='+id+'>'+id+'</span></td>';//좌석이름 A1,A2,,,
        $('.movSeats tr:nth-child('+i+')').append(appendString);
    }
    function appendBlack(i){
        appendString='<td><span class="tdBox black"></span></td>';//좌석이름 A1,A2,,,
        $('.movSeats tr:nth-child('+i+')').append(appendString);
    }
    
    $('table tbody tr td').click(function(){
        var num = counting();        
        var ClassName = $(this).find('span').attr('class');
        ClassName = ClassName.split(" ");// <td><span class='tdBox greenColor'> 클래스이름 분리
        var $seatList=$('.movSeatList input').val();
        if(num>0&&countSeats<=num){
            if (ClassName[2] == 'greenColor') {// 예약할 좌석이 greenColor 선택시
                $(this).find('span').removeClass('greenColor');
                countSeats--;
                var preSeats=$seatList.split(" ");
                $seatList="";
                var tmp = new Array();
                for(var j=0;j<preSeats.length;j++){
                    if(preSeats[j]!=''){
                        tmp.push(preSeats[j]);
                    }                    
                }
                for(var j=0;j<tmp.length;j++){
                    if(tmp[j]==$(this).find('span').attr('id')){
                        continue;
                    }else{
                        $seatList+=tmp[j]+" ";
                    }               
                }
                $('.movSeatList input').val($seatList);
            }else{
                if(countSeats>=num){
                    return;
                }else if(ClassName[1]=='avail'){
                    $(this).find('span').addClass("greenColor");
                    // $(this).removeClass("avail");
                    countSeats++;
                    seatArr.push($(this).find('span').attr('id'));                    
                    $seatList = $seatList  + $(this).find('span').attr("id") + ' ';
                    $('.movSeatList input').val($seatList);
                } 
            } //if else
        }//if
           
    })
    
    $('.pay').click(function(){ 
    	var movScheduleCode=$('#scheduleCode').val();
        var movDetailCode=$('#movDetailCode').val();
        var movName=$('.two').attr("name");
        var movType=$('#type').val();
        var movTheater=$('#theater').attr("data");
        var movDate=$('#date').val();
        var movTime=$('#time').val();
        var movPeopleSum=$('.peopleSum').val();
        var movSeat=$('#seat').val();
        var movAge=$('#age').val();   	
    	
        var content = "<div>" +
        		"<div>제목 : "+movName+"</div>" +
        		"<div>"+movType+"</div>" +
        		"<div>"+movTheater+"</div>" +
        		"<div>"+movDate+" "+movTime+"</div>" +
        		"<div>인원 : "+movPeopleSum+"명</div>"+
        		"<div>좌석 : "+movSeat+"</div>" +
        		"<div>"+movAge+"</div>" +
        		"</div>";
        
         openPop({
            title : '예매 내용 확인' ,
            description : content
        }) ;
        
        // 좌석 입력텍스트상자의 숫자와 예약할(greenColor)의 개수와 비교
        var UserCount=0;
        var idList='';
        var table=document.getElementById("movSeats");//좌석테이블 아이디 저장
        for (var i = 0, row; row = table.rows[i]; i++) {// #table tr
            for (var j = 1, col; col = row.cells[j]; j++) {// #table tr td
                if (col.firstChild != null) {// #table tr td span
                    var ClassName = col.firstChild.className;// #table tr td span .class
                    if (ClassName != '' && typeof ClassName !== "undefined" && ClassName !== null) { // check className
                        ClassName = ClassName.split(" ");// to className[]
                        if (ClassName[2] == 'greenColor') {// check greenColor
                            UserCount++;// greenColor to a UserCount
                            // .table > tbody > tr의 i번째 > td의 j+1 번째의 id속성값 + ','
                            // if() 
                            idList += $('.movSeats tbody tr:nth-child(' + (i+1) + ') td:nth-child(' + (j+1) + ') span').attr('id') + ',';
                            
                            // greenColor to a redColor
                            // $('.movSeats tbody tr:nth-child(' + i + ') td:nth-child(' + (j + 1) + ') span').removeClass('greenColor').addClass('redColor');
                        }// if                        
                    }// if
                }// if
            }// for
        }// for
        console.log(idList);
        var peopleArr=new Array();
        $(".numArea").each(function(){
        	peopleArr.push($(this).attr("value"));
        });    
        $(document).on("click",'button[data-type="confirm"]',function(){
        	var $form = $('<form></form>');
            $form.attr('name','newForm');
            $form.attr('method', 'post');
            $form.attr('charset', 'UTF-8');
            $form.attr('action', 'movPay.do');
            
            $form.append($('<input/>',{type:'hidden', name:'peopleArr', value:peopleArr}));//사람 수 배열
            $form.append($('<input/>',{type:'hidden', name:'movType', value:movType}));// 영화타입 2D
            $form.append($('<input/>',{type:'hidden', name:'movScheduleCode', value:movScheduleCode}));// 스케줄코드
            $form.append($('<input/>',{type:'hidden', name:'movDetailCode', value:movDetailCode}));// 디테일코드
            $form.append($('<input/>',{type:'hidden', name:'movTheater', value:movTheater}));// 관 번호
            $form.append($('<input/>',{type:'hidden', name:'movIdList', value:idList}));// 관 번호
            ///////////선택한 좌석 배열로 넘기기
//            var $seatSel = $('<select/>',{type:'hidden', multiple:'multiple', name:'seatlist', value:idList});
//            var $idArray = idList.split(',');
//            for(var i=0; i<$idArray.length; i++) {
//                alert($idArray[i]);
//            	$('<option/>',{type:'hidden',selected:'selected', name:'movSeatList', value:$idArray[i]}).appendTo($seatSel);
//            }
//            $form.append($seatSel);
            
            $form.appendTo('body');
            $form.submit();        	
        })
    })
})