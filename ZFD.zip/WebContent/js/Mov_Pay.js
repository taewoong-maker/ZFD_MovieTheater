$(function(){
   $('.bottomPay').click(function(){
	   var array=$('#array').val();
	   var movType=$('#movType').val();
	   var movScheduleCode=$('#movScheduleCode').val();
	   var movDetailCode=$('#movDetailCode').val();
	   var movTheater=$('#movTheater').val();
	   var movSeatList=$('#movSeatList').val();
	   var movIdList=$('#movIdList').val();
	   
//	   console.log(movSeatList);
	   alert(movIdList);
//	   alert(movTheater);
	   var $form = $('<form></form>');
       $form.attr('name','newForm');
       $form.attr('method', 'post');
       $form.attr('charset', 'UTF-8');
       $form.attr('action', 'movReserveInsert.do');
       
       $form.append($('<input/>',{type:'hidden', name:'peopleArr', value:array}));//사람 수 배열
       $form.append($('<input/>',{type:'hidden', name:'movType', value:movType}));// 영화타입 2D
       $form.append($('<input/>',{type:'hidden', name:'movScheduleCode', value:movScheduleCode}));// 스케줄코드
       $form.append($('<input/>',{type:'hidden', name:'movDetailCode', value:movDetailCode}));// 디테일코드
       $form.append($('<input/>',{type:'hidden', name:'movTheater', value:movTheater}));// 관 번호
       $form.append($('<input/>',{type:'hidden', name:'movIdList', value:movIdList}));// 좌석 리스트
       $form.appendTo('body');
       $form.submit();      
   })
});