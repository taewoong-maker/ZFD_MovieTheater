//Mov_Login.jsp;

$('.message').click(function(){
   $('form').animate({height: "toggle", opacity: "toggle"}, "slow");
});

function SignupCheck(){
		var engNum = /^[a-zA-Z0-9]{4,16}$/
		var NickNum = /^[a-zA-Z0-9]{2,10}$/
		var PhoneNum = /^[a-zA-Z0-9]{11,11}$/
		var BirthNum = /^\d{4}-\d{2}-\d{2}$/;
		var id =document.Signup.id.value;
		var pwd =document.Signup.pwd.value;
		var pwd1 =document.Signup.pwd1.value;
		var nick =document.Signup.nick.value;
		var tel =document.Signup.tel.value;
		var birth =document.Signup.birth.value;
	
		if(engNum.test(id)==false){
		 document.getElementById("id_ck").innerHTML="<font style='font-size:12pt; color:red'>*아이디를 4~16자로 입력하세요*</font>";
	     return;
	    }else{
	          document.getElementById("id_ck").innerHTML="";
		}
		if(engNum.test(pwd)==false){
			 document.getElementById("pwd_ck").innerHTML="<font style='font-size:12pt; color:red'>*비밀번호를 4~16자로 입력하세요*</font>";
		     return;
		}else{
		          document.getElementById("pwd_ck").innerHTML="";
		}
		if(pwd == pwd1){
			
			 document.getElementById("pwd_ck").innerHTML="";
		    
		}else{
			 document.getElementById("pwd_ck").innerHTML="<font style='font-size:12pt; color:red'>*두개의 비밀번호는 같아야 합니다.*</font>";
			 return;
	}
		if(NickNum.test(nick)==false){
			 document.getElementById("nick_ck").innerHTML="<font style='font-size:12pt; color:red'>*닉네임를 2~10자로 입력하세요*</font>";
		     return;
		}else{
		     document.getElementById("nick_ck").innerHTML="";
		}
		if(PhoneNum.test(tel)==false){
			 document.getElementById("tel_ck").innerHTML="<font style='font-size:12pt; color:red'>*핸드폰번호를 입력하세요*</font>";
		     return;
		}else{
		     document.getElementById("tel_ck").innerHTML="";
		}
		if(BirthNum.test(birth)==false){
			 document.getElementById("birth_ck").innerHTML="<font style='font-size:12pt; color:red'>*생년월일을 입력하세요*</font>";
		     return;
		}else{
		     document.getElementById("birth_ck").innerHTML="";
		}
		 document.Signup.submit();
	}//end

function execDaumPostcode() {
    new daum.Postcode({
        oncomplete: function(data) {
            var fullAddr = '';
            var extraAddr = '';
            
            if (data.userSelectedType === 'R') fullAddr = data.roadAddress;
            else fullAddr = data.jibunAddress;

            if(data.userSelectedType === 'R') {
                if(data.bname !== '') extraAddr += data.bname;
                if(data.buildingName !== '') extraAddr += (extraAddr !== '' ? ', ' + data.buildingName : data.buildingName);
                
                fullAddr += (extraAddr !== '' ? ' ('+ extraAddr +')' : '');
            }

        document.getElementById('jusocode').value = data.zonecode; //5자리 새우편번호 사용
           //document.getElementById("jusocode").value = data.postcode;
           document.getElementById("juso1").value = fullAddr;
           document.getElementById("juso2").focus();
        }
    }).open();
}
//Mov_MyPage.jsp
$(function() {
    var PhoneNum = /[^a-zA-Z]{10,11}$/;
    var BirthNum = /^\d{4}-\d{2}-\d{2}$/;
	$(".update2").click(function() {
        if(PhoneNum.test($('.phoneck').val())){
            $(".len").text("");
        }
        else{
            $(".len").text("*-를제외하고입력하시오.*");
            $(".len").css("color","red");
        }
        if(BirthNum.test($('.birthck').val())){
             $(".len2").text("");
         }
         else{
            $(".len2").text("*생년월일을 YYYY-MM-DD로 입력하시오.*");
            $(".len2").css("color","red");
         }
		if(PhoneNum.test($('.phoneck').val())&&BirthNum.test($('.birthck').val())){
			$('.MypageEdit').submit();}
    });
});
