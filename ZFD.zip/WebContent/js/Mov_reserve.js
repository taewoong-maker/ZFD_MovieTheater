$(function(){
    $('.scheduletime').click(function(){
    	var day = $(this).attr('data-day');
    	var mov = $(this).attr('data-mov');
    	var year= $(this).attr('data-year');
    	location.href="movreserveList.do?code="+mov+"&Rday="+day+"&date="+year;
    	
    	
//        $(this).addClass('active');
//        $(this).siblings().removeClass('active');
//        
//        var code = $(this).attr('data-code');
//        console.log(code);
//        var $type = $('.'+code+":nth-child(1)").val();
//        var $age = $(this).children("input:nth-child(2)").val();
//        console.log($type);
//        console.log($age);
    })//scheduletimeend

})//jquery end